<?php $__env->startSection('title-bar'); ?>
	<?php echo $__env->make('partials._titlebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container">
		<div class="section-details">
            <h2>Success!</h2>
            <p>You have successfully submitted your booking. We sent you an email containing the Reference Number of your booking to <?php echo e($email); ?> so you can revisit it in the future and change some things if needed. Thank you!</p>
        </div>
    </div>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>