<?php $__env->startSection('styles'); ?>
    <?php echo Html::style('css/bootstrap-datetimepicker.min.css'); ?>

    <?php echo Html::style('/css/bootstrap-select.min.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-bar'); ?>
    <?php echo $__env->make('partials._titlebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <div class="section-details">
                    <h2>Start new booking</h2>
                    <p>To start a new booking, please complete the information below.</p>
                </div>
                <hr>
                <div class="new-boooking-wrapper clearfix">
                    <?php echo Form::open(['route' => 'dateDetails', 'method' => 'POST']); ?>

                        <div class="form-section">
                            <h3>Accommodation Details</h3>
                            <div class="form-group">
                                <?php echo e(Form::label('chalet_id', 'Chalet')); ?>

                                <select id="chalet_id" name="chalet_id" class="col-md-12 custom-select selectpicker" data-show-subtext="true" data-live-search="true">
                                    <?php $__currentLoopData = $accs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <option value="<?php echo e($acc->id); ?>" data-subtext="<?php echo e($acc->operator->name); ?>" <?php echo e($acc->id == '2' ? 'selected="selected"' : ''); ?>><?php echo e($acc->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </select>
                            </div>
                            <div id="chalet_name" class="form-group hidden">
                                <?php echo e(Form::label('chalet_name', 'Chalet Name')); ?>

                                <?php echo e(Form::text('chalet_name', null, array('class' => 'form-control'))); ?>

                            </div>
                        </div>
                        <hr>
                        <!--
                        <div class="form-section">
                            <h3>Party Leader Details</h3>
                            <div class="form-group">
                                <?php echo e(Form::label('party_leader', 'Party Leader Name')); ?>

                                <?php echo e(Form::text('party_leader', null, array('class' => 'form-control'))); ?>

                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('party_email', 'Email Address')); ?>

                                <?php echo e(Form::text('party_email', null, array('class' => 'form-control'))); ?>

                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('party_mobile', 'Mobile Number')); ?>

                                <?php echo e(Form::text('party_mobile', null, array('class' => 'form-control'))); ?>

                            </div>
                        </div>
                        <hr>
                        -->
                        <div class="form-section">
                            <h3>Dates</h3>
                            <div class="form-group">
                                <?php echo e(Form::label('arrival_dtp', 'Arrival Date/Time')); ?>

                                <div class='input-group date' id='arrival_dtp'>
                                    <input name="arrival_dtp" type='text' class="form-control" required />
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('departure_dtp', 'Departure Date/Time')); ?>

                                <div class='input-group date' id='departure_dtp'>
                                    <input name="departure_dtp" type='text' class="form-control" required />
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('mountain_dtp', 'First day on Mountain')); ?>

                                <div class='input-group date' id='mountain_dtp'>
                                    <input name="mountain_dtp" type='text' class="form-control" required />
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <!--
                        <div class="form-section">
                            <h3>Terms and Conditions</h3>
                            <div class="form-group">
                                Please check the box below to show that you agree with our terms and conditions.
                                <div class="checkbox">
                                    <label>
                                    <?php echo e(Form::checkbox('terms_and_conditions', null)); ?> I agree with the SkiHire2U terms and conditions.
                                    </label>
                                </div>
                            </div>
                        </div>
                        <hr>
                        -->
                        <?php echo e(Form::submit('Continue', array('class' => 'btn btn-success btn-lg'))); ?>


                    <?php echo Form::close(); ?>

                </div>
            </div>
            <div class="col-md-3">
                <?php echo $__env->make('partials._sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo Html::script('js/bootstrap-select.min.js'); ?>

    <?php echo Html::script('js/moment-with-locales.js'); ?>

    <?php echo Html::script('js/bootstrap-datetimepicker.min.js'); ?>

    <script type="text/javascript">
        jQuery(document).ready(function() {
            jQuery('#chalet_id').change(function() {
                var val = jQuery('#chalet_id').val();
                if( val == '1') {
                    jQuery('#chalet_name').removeClass('hidden');
                } else {
                    jQuery('#chalet_name').addClass('hidden');
                }
            });

            jQuery('#arrival_dtp').datetimepicker({
                format: 'DD-MM-YYYY HH:mm',
                minDate: moment(),
                sideBySide: true
            });
            jQuery('#departure_dtp').datetimepicker({
                format: 'DD-MM-YYYY HH:mm',
                minDate: moment(),
                useCurrent: false,
                sideBySide: true
            });
            jQuery('#mountain_dtp').datetimepicker({
                format: 'DD-MM-YYYY HH:mm',
                minDate: moment(),
                useCurrent: false,
                sideBySide: true
            });
            jQuery("#arrival_dtp").on("dp.change", function (e) {
                var mtn = jQuery('#mountain_dtp').data("DateTimePicker").date();
                if(mtn) {
                    jQuery('#departure_dtp').data("DateTimePicker").minDate(mtn);
                } else {
                    jQuery('#departure_dtp').data("DateTimePicker").minDate(e.date);
                }
                jQuery('#mountain_dtp').data("DateTimePicker").minDate(e.date);
            });
            jQuery("#departure_dtp").on("dp.change", function (e) {
                var mtn = jQuery('#mountain_dtp').data("DateTimePicker").date();
                if(mtn) {
                    jQuery('#arrival_dtp').data("DateTimePicker").maxDate(mtn);
                } else {
                    jQuery('#arrival_dtp').data("DateTimePicker").maxDate(e.date);
                }
                jQuery('#mountain_dtp').data("DateTimePicker").maxDate(e.date);
            });
            jQuery("#mountain_dtp").on("dp.change", function (e) {
                jQuery('#arrival_dtp').data("DateTimePicker").maxDate(e.date);
                jQuery('#departure_dtp').data("DateTimePicker").minDate(e.date);
            });
        });
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>