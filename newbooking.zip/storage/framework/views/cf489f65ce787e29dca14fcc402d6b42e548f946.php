<?php $__env->startSection('title-bar'); ?>
	<?php echo $__env->make('partials._adminMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="/css/admin.css">
<style>
@media  print{
    @page  {
        size: portrait;
    }
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div id="invoice" class="printable" media="print">
		<h2>Edit Invoice</h2>
		<?php echo Form::open(array('route' => array('invoice.update', $booking->id), 'method' => 'PUT', 'class' => 'invoice-edit', 'id' => 'invoice-edit' )); ?>

		<table class="table webee-table table-bordered">
			<thead>
				<tr>
					<th></th>
					<th>Name</th>
					<th>Package</th>
					<th>Duration/Add on</th>
					<th>Price</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $booking->rentals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<tr>
					<td><?php echo e($loop->iteration); ?></td>
					<td><strong><?php echo e($rental->name); ?></strong></td>
					<td>
						<p><?php echo e($packageModel->getPackageName($rental->package_id)); ?></p>
						<p><strong><?php echo e($packageModel->getPackageLevel($rental->package_id)); ?></strong></p>
						<p>Duration: <strong><?php echo e($rental->duration); ?> <?php echo e(($rental->duration == 1) ? 'day' : 'days'); ?></strong></p>
					</td>
					<td>
						<?php if($rental->addons->boots == 'on'): ?>
						<p>Boots</p>
						<?php endif; ?>
						<?php if($rental->addons->helmet == 'on'): ?>
						<p>
							Helmet
                        	<?php if( (int) $rental->age <= 3 || $packageModel->getPackageType($rental->package_id) == 'Child'): ?>
					    	<small class="free-helmet">FREE!</small>
					    	<?php endif; ?>
						</p>
						<?php endif; ?>
						<?php if($rental->addons->insurance == 'on'): ?>
						<p>Insurance</p>
						<?php endif; ?>
                    </td>
					<td>
						<div class="form-group">
							<label for="rental_price[<?php echo e($rental->name); ?>]">Price</label>
							<input name="rental_price[<?php echo e($rental->name); ?>]" type="number" step="any" class="rental-price form-control" value="<?php echo e($invoice->rental_prices[$rental->name]['price']); ?>" required data-id="<?php echo e($rental->id); ?>">
                        </div>
                        <div class="form-group">
							<label for="rental_discount[<?php echo e($rental->name); ?>]">Discount</label>
							<input name="rental_discount[<?php echo e($rental->name); ?>]" type="number" step="any" class="rental-discount form-control" value="<?php echo e($invoice->rental_prices[$rental->name]['discount']); ?>" required data-id="<?php echo e($rental->id); ?>">
                        </div>
                        <div class="form-group">
							<label for="rental_total[<?php echo e($rental->name); ?>]">Discounted Price</label>
							<input name="rental_total[<?php echo e($rental->name); ?>]" type="number" step="any" class="rental-total form-control" value="<?php echo e($invoice->rental_prices[$rental->name]['total']); ?>" readonly data-id="<?php echo e($rental->id); ?>">
                        </div>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</tbody>
			<tfoot>
				<tr>
					<td colspan="4" class="total-cell">Total</td>
					<td>
						<div class="form-group">
							<label for="subtotal">Subtotal</label>
							<input name="subtotal" type="number" step="any" id="invoice-subtotal" class="form-control" value="<?php echo e($invoice->subtotal); ?>" readonly data-id="subtotal">
                        </div>
                        <div class="form-group">
							<label for="discount">Discount</label>
							<input name="discount" type="number" step="any" id="invoice-discount" class="form-control" value="<?php echo e($invoice->discount); ?>" required data-id="discount">
                        </div>
                        <div class="form-group">
							<label for="total">Total</label>
							<input name="total" type="number" step="any" id="invoice-total" class="form-control" value="<?php echo e($invoice->total); ?>" readonly data-id="total">
                        </div>
                        <button type="submit" class="btn btn-success right">Save</button>
                    </td>
				</tr>
			</tfoot>
		</table>
		<?php echo Form::close(); ?>

	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	jQuery(document).ready(function() {
		jQuery('.rental-price').change(function() {
			var id = jQuery(this).data('id');
			var total = returnTotal(id);

			updateSubtotal();
			updateTotal();

			jQuery('.rental-total[data-id="' + id + '"]').val(total.toFixed(2));
		});

		jQuery('.rental-discount').change(function() {
			var id = jQuery(this).data('id');
			var total = returnTotal(id);

			updateDiscount();
			updateTotal();

			jQuery('.rental-total[data-id="' + id + '"]').val(total.toFixed(2));
		});

		jQuery('#invoice-discount').change(function() {
			updateTotal();
		});

		jQuery('.rental-total').change(function() {
			alert(jQuery(this).val());
		});

		jQuery(window).keydown(function(event){
			if(event.keyCode == 13) {
				event.preventDefault();
				return false;
			}
		});
	});

	function returnTotal(id) {
		var price = parseFloat(jQuery('.rental-price[data-id="' + id + '"]').val());
		var discount = parseFloat(jQuery('.rental-discount[data-id="' + id + '"]').val());

		return price - discount;
	}

	function updateSubtotal() {
		//var subtotal = jQuery('#invoice-subtotal').val();
		var subtotal = 0;
		jQuery('tr .rental-price').each(function() {
			subtotal += parseFloat(jQuery(this).val());
		});

		jQuery('#invoice-subtotal').val(subtotal.toFixed(2));
	}

	function updateDiscount() {
		//var discount = jQuery('#invoice-discount').val();
		var discount = 0;
		jQuery('tr .rental-discount').each(function() {
			discount += parseFloat(jQuery(this).val());
		});

		jQuery('#invoice-discount').val(discount.toFixed(2));
	}

	function updateTotal() {
		var subtotal = parseFloat(jQuery('#invoice-subtotal').val());
		var discount = parseFloat(jQuery('#invoice-discount').val());
		var total = subtotal - discount;

		jQuery('#invoice-total').val(total.toFixed(2));
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>