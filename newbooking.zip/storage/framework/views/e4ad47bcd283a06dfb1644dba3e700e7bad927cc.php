<?php $__env->startSection('title-bar'); ?>
	<?php echo $__env->make('partials._adminMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="/css/admin.css">
<style>
@media  print{
    @page  {
        size: portrait;
    }
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<h2>Invoice</h2>
	<div class="admin-button-container">
		<a href="<?php echo e(route('invoice.edit', $booking->id)); ?>" class="btn btn-success btn-icon" title="Edit Invoice"><i class="fa fa-pencil"></i>Edit</a>
		<a id="print-invoice" href="#" class="btn btn-info btn-icon" title="Print Invoice"><i class="fa fa-print"></i>Print</a>
	</div>
</div>
<div class="container">
	<div id="invoice" class="printable" media="print">
		<h2>Booking Invoice</h2>
		<div class="booking-data">
			<p><strong>Chalet: </strong> <?php echo e($booking->chalet_name); ?></p>
			<?php if($booking->chalet_id == 1): ?>
			<p><strong>Accommodation Address: </strong> <?php echo e($booking->chalet_address); ?></p>
			<?php endif; ?>
			<p><strong>Party Leader: </strong> <?php echo e($booking->party_leader); ?></p>
			<p><strong>Party Email: </strong> <?php echo e($booking->party_email); ?></p>
			<p><strong>Party Mobile: </strong> <?php echo e($booking->party_mobile); ?></p>
			<p><strong>Reference Number: </strong> <?php echo e($booking->reference_number); ?></p>
			<p><strong>Arrival Date: </strong> <?php echo e($booking->arrival_datetime); ?></p>
			<p><strong>Departure Date: </strong> <?php echo e($booking->departure_datetime); ?></p>
			<p><strong>First Day on Mountain: </strong> <?php echo e($booking->mountain_datetime); ?></p>
		</div>
		<hr>
		<table class="table webee-table table-bordered">
			<thead>
				<tr>
					<th></th>
					<th>Name</th>
					<th>Package</th>
					<th>Duration/Add on</th>
					<th>Price</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $booking->rentals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<tr>
					<td><?php echo e($loop->iteration); ?></td>
					<td><strong><?php echo e($rental->name); ?></strong></td>
					<td>
						<p><?php echo e($packageModel->getPackageName($rental->package_id)); ?></p>
						<p><strong><?php echo e($packageModel->getPackageLevel($rental->package_id)); ?></strong></p>
						<p>Duration: <strong><?php echo e($rental->duration); ?> <?php echo e(($rental->duration == 1) ? 'day' : 'days'); ?></strong></p>
					</td>
					<td>
						<?php if($rental->addons->boots == 'on'): ?>
						<p>Boots</p>
						<?php endif; ?>
						<?php if($rental->addons->helmet == 'on'): ?>
						<p>
							Helmet
                        	<?php if( (int) $rental->age <= 3 || $packageModel->getPackageType($rental->package_id) == 'Child'): ?>
					    	<small class="free-helmet">FREE!</small>
					    	<?php endif; ?>
						</p>
						<?php endif; ?>
						<?php if($rental->addons->insurance == 'on'): ?>
						<p>Insurance</p>
						<?php endif; ?>
                    </td>
					<td>
						<?php if($invoice->chalet_discount): ?>
                        <p class="price">&euro; <?php echo e($invoice->rental_prices[$rental->name]['total']); ?></p>
                        <p class="price strike"><small>&euro; <?php echo e($invoice->rental_prices[$rental->name]['price']); ?></small></p>
                        <p class="discount-amount">Less: ( &euro; - <small><?php echo e($invoice->rental_prices[$rental->name]['discount']); ?></small> )</p>
                        <?php else: ?>
                        <p class="price">&euro; <?php echo e($invoice->rental_prices[$rental->name]['total']); ?></p>
                        <?php endif; ?>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</tbody>
			<tfoot>
				<tr>
					<td colspan="4" class="total-cell">Total</td>
					<td class="total-prices">
                        <?php if($invoice->discount != 0): ?>
                        <p class="total-price">&euro; <?php echo e($invoice->total); ?></p>
                        <p class="total-price strike"><small>&euro; <?php echo e($invoice->subtotal); ?></small></p>
                        <p class="discount-amount">Less: ( &euro; - <small><?php echo e($invoice->discount); ?></small> )</p>
                        <?php else: ?>
                        <p class="total-price">&euro; <?php echo e($invoice->total); ?></p>
                        <?php endif; ?>
                    </td>
				</tr>
			</tfoot>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
	jQuery(document).ready(function() {

		jQuery('#print-invoice').click(function(e) {
			e.preventDefault();
			var printContents = jQuery('#invoice').html();
			var originalContents = jQuery('body').html();

			jQuery('body').html(printContents);

			window.print();

			location.reload();

			return false;

			//jQuery('body').html(originalContents);
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>