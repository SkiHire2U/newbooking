<div class="section-details">
    <h2>Find a booking</h2>
    <p>Input the details below to edit your existing booking.</p>
</div>
<hr>
<div class="existing-boooking-wrapper clearfix">
    <?php echo Form::open(['route' => 'reference', 'method' => 'POST']); ?>

    	<div class="form-group">
            <?php echo e(Form::label('party_leader', 'Party Leader Email')); ?>

            <?php echo e(Form::email('party_leader', old('party_leader'), array('class' => 'form-control', 'required' => ''))); ?>

        </div>
        <div class="form-group">
            <?php echo e(Form::label('reference_code', 'Reference Code')); ?>

            <?php echo e(Form::text('reference_code', old('reference_code'), array('class' => 'form-control', 'required' => ''))); ?>

        </div>
    	<?php echo e(Form::submit('Find Booking', array('class' => 'btn btn-primary'))); ?>


    <?php echo Form::close(); ?>

</div>