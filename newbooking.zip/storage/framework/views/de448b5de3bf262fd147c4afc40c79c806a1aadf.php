<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Styles -->
    <link href="/css/app.css" rel="stylesheet">

    <!-- Fonts -->
    <?php echo Html::style('/fonts/catamaran/stylesheet.css'); ?>


    <?php echo Html::style('font-awesome/css/font-awesome.min.css'); ?>

    <?php echo Html::style('/css/style.css'); ?>


    <?php echo $__env->yieldContent('styles'); ?>

    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>
    </script>
</head>
<body>
    <nav class="navbar navbar-default navbar-static-top">
        <div class="container">
            <div class="navbar-header">

                <!-- Collapsed Hamburger -->
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                    <span class="sr-only">Toggle Navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>

                <!-- Branding Image -->
                <div class="brand-wrapper clearfix">
                    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                        <img class="logo" src="/images/logo.png">
                    </a>
                </div>
            </div>

            

            <div class="collapse navbar-collapse" id="app-navbar-collapse">
                <!-- Left Side Of Navbar -->
                <ul class="nav navbar-nav">
                    &nbsp;
                </ul>

                <!-- Right Side Of Navbar -->
                <ul class="nav navbar-nav navbar-right">
                    <!-- Authentication Links -->
                    <!--
                    <?php if(Auth::guest()): ?>
                        <li><a href="<?php echo e(url('/login')); ?>">Login</a></li>
                        <li><a href="<?php echo e(url('/register')); ?>">Register</a></li>
                    <?php else: ?>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                            </a>

                            <ul class="dropdown-menu" role="menu">
                                <li>
                                    <a href="<?php echo e(url('/logout')); ?>"
                                        onclick="event.preventDefault();
                                                 document.getElementById('logout-form').submit();">
                                        Logout
                                    </a>

                                    <form id="logout-form" action="<?php echo e(url('/logout')); ?>" method="POST" style="display: none;">
                                        <?php echo e(csrf_field()); ?>

                                    </form>
                                </li>
                            </ul>
                        </li>
                    <?php endif; ?>
                    -->
                </ul>
            </div>
        </div>
    </nav>

    <?php echo $__env->yieldContent('title-bar'); ?>

    <?php echo $__env->make('partials._messages', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <?php echo $__env->yieldContent('content'); ?>

    <footer>
        <div class="container">
            <div class="copyright">
                <a href="https://www.web-design-malta.com" target="_blank" title="Web Design Malta" style="text-decoration:none; ">Web Design in Malta</a>
            </div>
        </div>
        <!--
        <div class="upper-footer">
            <div class="container">
                <div class="row">
                    <div class="col-md-3">
                        <div class="footer-column">
                            <a href="http://skihire2u.com/">
                                <img src="http://skihire2u.com/wp-content/uploads/2016/09/SkiHire2U-logo-white-grey-with-strap-line-400w.png" alt="logo">
                            </a>
                            <div class="social-icons">
                                <ul>
                                    <li>
                                        <a href="#" target="_blank">
                                            <i class="fa fa-facebook"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank">
                                            <i class="fa fa-twitter"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank">
                                            <i class="fa fa-instagram"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank">
                                            <i class="fa fa-linkedin"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" target="_blank">
                                            <i class="fa fa-dribble"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="footer-column">
                            <h4 class="qodef-footer-widget-title">Our Location</h4>
                            <p>Chalet Marmerlarde<br>2451 Route de la Dranse<br>74390 Châtel<br>France</p>
                        </div>
                        <a class="" href="javascript:void(0)">
                            <i class="ion-link"></i>Helpful Links
                        </a>
                    </div>
                </div>
            </div>
        </div>
        -->
    </footer>

    <!-- Scripts -->
    <script type="text/javascript" src="/js/app.js"></script>
    <script type="text/javascript" src="/js/scripts.js"></script>

    <?php echo $__env->yieldContent('scripts'); ?>

</body>
</html>
