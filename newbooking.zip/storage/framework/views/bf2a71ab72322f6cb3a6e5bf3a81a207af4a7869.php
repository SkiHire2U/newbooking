<div id="rack-data" class="rack-data-container">
	<!-- <a id="close-side" href="#"><span class="glyphicon glyphicon-remove" aria-hidden="true"></span></a> -->
	<div class="rack-data-wrapper">
		<div class="party-details">
			<h3>Accommodation Details</h3>
			<span>Chalet Name: <strong><?php echo e($chalet['name']); ?></strong></span>
			<span>Arrival Date/Time: <strong><?php echo e($details['arrival_dtp']); ?></strong></span>
			<span>Departure Date/Time: <strong><?php echo e($details['departure_dtp']); ?></strong></span>
			<span>First day on Mountain: <strong><?php echo e($details['mountain_dtp']); ?></strong></span>
		</div>
		<hr>
		<div class="rack-details">
			<h3>Rack Items</h3>
			<?php if(count($packages) > 0): ?>
			<ul class="rack-list">
				<?php $total = 0; $origTotal = 0; ?>
				<?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<li class="rack-item">
					<div class="hidden">
					<?php echo Form::open(array('route' => array('removeFromRack', $package['package_renter']), 'method' => 'POST', 'class' => 'remove-from-rack', 'data-id' => $package['package_renter'] )); ?>

					<?php echo Form::close(); ?>

					</div>
					<a href="#" class="remove-from-rack-btn" data-toggle="modal" data-target="#remove-from-rack-modal" data-id="<?php echo e($package['package_renter']); ?>"><i class="glyphicon glyphicon-trash" aria-hidden="true"></i></a>
					<h4><?php echo e($package['package_renter']); ?></h4>
					<span><strong><?php echo e($packageModel->getPackageName($package['package_id'])); ?></strong></span>
					<?php if($packageModel->getPackageLevel($package['package_id'])): ?>
					<span><strong><?php echo e($packageModel->getPackageLevel($package['package_id'])); ?></strong></span>
					<?php endif; ?>
					<span>Duration: <?php echo e($package['rent_days']); ?> <?php echo e(($package['rent_days'] == 1) ? 'day' : 'days'); ?></span>
					<div class="row">
						<div class="col-md-6">
							<span>Boots: <?php echo e(($package['addon']['boots'] == 'on') ? 'Yes' : 'No'); ?></span>
							<span>Helmet: <?php echo e(($package['addon']['helmet'] == 'on') ? 'Yes' : 'No'); ?></span>
							<span>Insurance: <?php echo e(($package['addon']['insurance'] == 'on') ? 'Yes' : 'No'); ?></span>
						</div>
						<div class="col-md-6">
							<?php if($chalet['discount']): ?>
							<span class="price">&euro; <?php echo e(number_format($prices[$package['package_renter']]['discounted'], 2, '.', ',')); ?></span>
							<span class="price strike">&euro; <?php echo e(number_format($prices[$package['package_renter']]['originalAmount'], 2, '.', ',')); ?></span>
							<span class="discount-amount">Less: ( - &euro; <small><?php echo e(number_format($prices[$package['package_renter']]['discountAmount'], 2, '.', ',')); ?></small> )</span>
							<?php else: ?>
							<span class="price">&euro; <?php echo e(number_format($prices[$package['package_renter']]['originalAmount'], 2, '.', ',')); ?></span>
							<?php endif; ?>
						</div>
					</div>
				</li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</ul>
			<div class="total-price-container">
				<div class="col-md-4">
					<h3>TOTAL:</h3>
				</div>
				<div class="col-md-8">
					<div class="total-price-wrapper">
						<?php if($chalet['discount']): ?>
						<span class="total-price">&euro; <?php echo e(number_format($prices['totalDiscounted'], 2, '.', ',')); ?></span>
						<span class="total-price strike">&euro; <?php echo e(number_format($prices['total'], 2, '.', ',')); ?></span>
						<?php else: ?>
						<span class="total-price">&euro; <?php echo e(number_format($prices['total'], 2, '.', ',')); ?></span>
						<?php endif; ?>
					</div>
				</div>
			</div>
			<?php else: ?>
			<div class="alert alert-info" role="alert">
				Rack is empty.
			</div>
			<?php endif; ?>
		</div>
	</div>
</div>
<div class="modal fade" id="remove-from-rack-modal" tabindex="-1" role="dialog" aria-labelledby="removeRenter">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="removal-modal-title">REMOVE PACKAGE FOR: %renter%</h4>
			</div>
			<div class="modal-body">
				<form>
	            	<input type="text" class="form-control hidden" id="remove-renter">
		        </form>
		        <p id="removal-body-text">Are you sure you would like to remove the package for <strong>%renter%</strong> from the rack?</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary" id="remove-from-rack-btn">Continue</button>
			</div>
		</div>
	</div>
</div>