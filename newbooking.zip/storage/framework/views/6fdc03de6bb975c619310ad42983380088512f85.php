<?php $__env->startSection('title-bar'); ?>
	<?php echo $__env->make('partials._adminMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="/css/admin.css">
<link rel="stylesheet" type="text/css" href="/css/jquery.dataTables.min.css">
<style>
@media  print{
    @page  {
        size: landscape;
    }
}
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<h2>Picking List</h2>
	<div class="admin-button-container">
		<a id="print-picking-list" href="#" class="btn btn-info btn-icon" title="Print Picking List"><i class="fa fa-print"></i>Print</a>
	</div>
</div>
<div class="container">
	<div id="picking-list" class="printable" media="print">
		<h4>Booking Information</h4>
		<div class="booking-data">
			<table class="webee-table">
				<tr>
					<td width="50%">
						<p><strong>Chalet: </strong> <?php echo e($booking->chalet_name); ?></p>
						<?php if($booking->chalet_id == 1): ?>
						<p><strong>Accommodation Address: </strong> <?php echo e($booking->chalet_address); ?></p>
						<?php endif; ?>
						<p><strong>Party Leader: </strong> <?php echo e($booking->party_leader); ?></p>
						<p><strong>Party Email: </strong> <?php echo e($booking->party_email); ?></p>
						<p><strong>Party Mobile: </strong> <?php echo e($booking->party_mobile); ?></p>
						<p><strong>Reference Number: </strong> <?php echo e($booking->reference_number); ?></p>
						<p><strong>Notes: </strong> <?php echo e($booking->notes); ?></p>
					</td>
					<td width="50%" class="booking-dates">
						<p><strong>Arrival Date: </strong> <?php echo e($booking->arrival_datetime); ?></p>
						<p><strong>First Day on Mountain: </strong> <?php echo e($booking->mountain_datetime); ?></p>
						<p><strong>Departure Date: </strong> <?php echo e($booking->departure_datetime); ?></p>
					</td>
				</tr>
			</table>
		</div>
		<hr>
		<table class="table webee-table table-bordered">
			<thead>
				<tr>
					<th></th>
					<th>Name</th>
					<th>Details</th>
					<th>Package/Notes</th>
					<th>Add on</th>
					<!-- <th>Ski</th> -->
					<th>Pole</th>
					<th>Boots</th>
					<!-- <th>Code</th> -->
					<th>DIN</th>
					<th class="serial-column" width="25%">Management Notes</th>
				</tr>
			</thead>
			<tbody>
				<?php $__currentLoopData = $booking->rentals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<tr>
					<td><?php echo e($loop->iteration); ?></td>
					<td><strong><?php echo e($rental->name); ?></strong></td>
					<td>
						<p><?php echo e($select['age'][$rental->age]); ?></p>
						<p><?php echo e($rental->sex); ?></p>
						<p>Ability: <strong><?php echo e($select['level'][$rental->ability]); ?></strong></p>
						<p>Height: <strong><?php echo e($select['height'][$rental->height]); ?></strong></p>
						<p>Weight: <strong><?php echo e($select['weight'][$rental->weight]); ?></strong></p>
					</td>
					<td>
						<p><?php echo e($packageModel->getPackageName($rental->package_id)); ?></p>
						<p><strong><?php echo e($packageModel->getPackageLevel($rental->package_id)); ?></strong></p>
						<?php if($rental->notes): ?>
						<p>Notes: <strong><?php echo e($rental->notes); ?></strong></p>
						<?php endif; ?>
					</td>
					<td>
						<?php if($rental->addons->boots == 'on'): ?>
						<p>Boots</p>
						<?php endif; ?>
						<?php if($rental->addons->helmet == 'on'): ?>
						<p>Helmet</p>
						<?php endif; ?>
						<?php if($rental->addons->insurance == 'on'): ?>
						<p>Insurance</p>
						<?php endif; ?>
                    </td>
					<!-- <td><p><strong><?php echo e($rental->ski_length); ?></strong></p></td> -->
					<td><p><strong><?php echo e($rental->pole_length); ?></strong></p></td>
					<td>
						<?php if($rental->addons->boots == 'on'): ?>
						<p><strong><?php echo e($rental->boot_size); ?></strong></p>
						<?php endif; ?>
					</td>
					<!-- <td><p><strong><?php echo e($rental->skier_code); ?></strong></p></td> -->
					<td><strong><?php echo e($rental->din); ?></strong></p></td>
					<td></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</tbody>
		</table>
	</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- <script type="text/javascript" src="/js/jquery.dataTables.min.js"></script> -->
<script type="text/javascript">
	jQuery(document).ready(function() {
		// jQuery('#dataTable').DataTable();

		jQuery('#print-picking-list').click(function(e) {
			e.preventDefault();
			var printContents = jQuery('#picking-list').html();
			var originalContents = jQuery('body').html();

			jQuery('body').html(printContents);

			window.print();

			location.reload();

			return false;

			//jQuery('body').html(originalContents);
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>