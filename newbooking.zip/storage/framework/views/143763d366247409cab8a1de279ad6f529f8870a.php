<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials._title-bar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <div class="section-details">
                    <h2>Start new booking</h2>
                    <p>To start a new booking, please complete the information below.</p>
                </div>
                <hr>
                <div class="new-boooking-wrapper clearfix">
                    <?php echo Form::open(['route' => 'booking.store']); ?>

                        <div class="section-title">
                            <h4>Accommodation Details</h4>
                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('chalet_id', 'Chalet')); ?>

                            <select name="chalet_id" class="col-md-12 custom-select selectpicker" data-show-subtext="true" data-live-search="true">
                                <option data-subtext="Rep California">Tom Foolery</option>
                                <option data-subtext="Sen California">Bill Gordon</option>
                                <option data-subtext="Sen Massacusetts">Elizabeth Warren</option>
                                <option data-subtext="Rep Alabama">Mario Flores</option>
                                <option data-subtext="Rep Alaska">Don Young</option>
                                <option data-subtext="Rep California" disabled="disabled">Marvin Martinez</option>
                            </select>
                        </div>
                        <div class="form-group hidden">
                            <?php echo e(Form::label('chalet_id', 'Main Applicant’s name & surname:')); ?>

                            <?php echo e(Form::text('chalet_id', null, array('class' => 'form-control'))); ?>

                        </div>

                    <?php echo Form::close(); ?>

                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>