<?php $__env->startSection('title-bar'); ?>
	<?php echo $__env->make('partials._titlebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<div class="container">
        <div class="row">
        	<div class="col-md-10">
        		<div class="section-details">
                    <h2>Booking Information</h2>
                    <p><strong>Almost done!</strong> Please complete the last bits of information required below.</p>
                </div>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="col-md-8">
                <div class="">
                	<?php echo Form::open(['route' => 'booking.store', 'method' => 'POST']); ?>

                	<div class="form-section">
                        <h3>Party Leader Details</h3>
                        <div class="form-group">
                            <?php echo e(Form::label('party_leader', 'Party Leader Name')); ?>

                            <?php echo e(Form::text('party_leader', null, array('class' => 'form-control', 'required' => ''))); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('party_email', 'Email Address')); ?>

                            <?php echo e(Form::email('party_email', null, array('class' => 'form-control', 'required' => ''))); ?>

                        </div>
                        <div class="form-group">
                            <?php echo e(Form::label('party_mobile', 'Mobile Number')); ?>

                            <?php echo e(Form::text('party_mobile', null, array('class' => 'form-control'))); ?>

                        </div>
                    </div>
                    <hr>
                    <div class="form-section">
                        <h3>Terms and Conditions</h3>
                        <div class="form-group">
                            Please check the box below to show that you agree with our terms and conditions.
                            <div class="checkbox">
								<label>
	                                <input name="terms_and_conditions" type="checkbox" required>
	                                I agree with the SkiHire2U terms and conditions.
                                </label>
                            </div>
                        </div>
                    </div>
                    <hr>
                    <?php echo e(Form::submit('Continue', array('class' => 'btn btn-success btn-lg'))); ?>

                    <?php echo Form::close(); ?>

                </div>
            </div>
            <div class="col-md-4">
        		<?php echo $__env->make('partials._rack', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        	</div>
        </div>
    </div>	
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    jQuery(document).ready(function() {
        jQuery('#remove-from-rack-modal').on('show.bs.modal', function (event) {
            var button = jQuery(event.relatedTarget);
            var renter = button.data('id');
            var modal = jQuery(this);

            modal.find('#removal-modal-title').text(renterReplace(modal.find('#removal-modal-title').text(), renter));
            modal.find('#removal-body-text').text(renterReplace(modal.find('#removal-body-text').text(), renter));
            modal.find('#remove-renter').val(renter);
        });

        jQuery('#remove-from-rack-btn').click(function (e) {
            e.preventDefault();
            var id = jQuery('#remove-renter').val();
            jQuery('.remove-from-rack[data-id="' + id + '"]').submit();
        });
    });

    function renterReplace(originalString, newString) {
        return originalString.replace(/%renter%/, newString);
    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>