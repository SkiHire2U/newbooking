<div class="modal fade" id="foot-size-conversion-table" tabindex="-1" role="dialog" aria-labelledby="footSizeConversionTable">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h3 class="modal-title">Foot Size Conversion Table</h3>
			</div>
			<div class="modal-body">
				<table class="table table-bordered">
					<thead>
						<tr>
							<th>EUROPE</th>
							<th>UK</th>
							<th>US (Men)</th>
							<th>US (Women)</th>
						<tr>
					</thead>
					<tbody>
						<tr>
							<th>25</th>
							<td>7 (Kids)</td>
							<td>8 (Kids)</td>
							<td></td>
						</tr>
						<tr>
							<th>26</th>
							<td>8 (Kids)</td>
							<td>9 (Kids)</td>
							<td></td>
						</tr>
						<tr>
							<th>27</th>
							<td>9 (Kids)</td>
							<td>10 (Kids)</td>
							<td></td>
						</tr>
						<tr>
							<th>28</th>
							<td>10 (Kids)</td>
							<td>11 (Kids)</td>
							<td></td>
						</tr>
						<tr>
							<th>29</th>
							<td>11 (Kids)</td>
							<td>12 (Kids)</td>
							<td></td>
						</tr>
						<tr>
							<th>30.5</th>
							<td>12 (Kids)</td>
							<td>13 (Kids)</td>
							<td></td>
						</tr>
						<tr>
							<th>31</th>
							<td>13 (Kids)</td>
							<td>13.5 (Kids)</td>
							<td></td>
						</tr>
						<tr>
							<th>32</th>
							<td>13.5 (Kids)</td>
							<td>1</td>
							<td></td>
						</tr>
						<tr>
							<th>33</th>
							<td>1</td>
							<td>2</td>
							<td></td>
						</tr>
						<tr>
							<th>34</th>
							<td>2</td>
							<td>3</td>
							<td></td>
						</tr>
						<tr>
							<th>35</th>
							<td>3</td>
							<td>4</td>
							<td>5</td>
						</tr>
						<tr>
							<th>35.5</th>
							<td>3.5</td>
							<td>4.5</td>
							<td>5.5</td>
						</tr>
						<tr>
							<th>36.5</th>
							<td>4</td>
							<td>5</td>
							<td>6</td>
						</tr>
						<tr>
							<th>37</th>
							<td>4.5</td>
							<td>5.5</td>
							<td>6.5</td>
						</tr>
						<tr>
							<th>38</th>
							<td>5</td>
							<td>6</td>
							<td>7</td>
						</tr>
						<tr>
							<th>38.5</th>
							<td>5.5</td>
							<td>6.5</td>
							<td>7.5</td>
						</tr>
						<tr>
							<th>39</th>
							<td>6</td>
							<td>7</td>
							<td>8</td>
						</tr>
						<tr>
							<th>40</th>
							<td>6.5</td>
							<td>7.5</td>
							<td>8.5</td>
						</tr>
						<tr>
							<th>40.5</th>
							<td>7</td>
							<td>8</td>
							<td>9</td>
						</tr>
						<tr>
							<th>41</th>
							<td>7.5</td>
							<td>8.5</td>
							<td>9.5</td>
						</tr>
						<tr>
							<th>42</th>
							<td>8</td>
							<td>9</td>
							<td>10</td>
						</tr>
						<tr>
							<th>42.5</th>
							<td>8.5</td>
							<td>9.5</td>
							<td>10.5</td>
						</tr>
						<tr>
							<th>43</th>
							<td>9</td>
							<td>10</td>
							<td>11</td>
						</tr>
						<tr>
							<th>44</th>
							<td>9.5</td>
							<td>10.5</td>
							<td>11.5</td>
						</tr>
						<tr>
							<th>44.5</th>
							<td>10</td>
							<td>11</td>
							<td>12</td>
						</tr>
						<tr>
							<th>45</th>
							<td>10.5</td>
							<td>11.5</td>
							<td></td>
						</tr>
						<tr>
							<th>45.5</th>
							<td>11</td>
							<td>12</td>
							<td></td>
						</tr>
						<tr>
							<th>46</th>
							<td>11.5</td>
							<td>12.5</td>
							<td></td>
						</tr>
						<tr>
							<th>47</th>
							<td>12</td>
							<td>13</td>
							<td></td>
						</tr>
						<tr>
							<th>47.5</th>
							<td>12.5</td>
							<td>13.5</td>
							<td></td>
						</tr>
						<tr>
							<th>48</th>
							<td>13</td>
							<td>14</td>
							<td></td>
						</tr>
						<tr>
							<th>48.5</th>
							<td>13</td>
							<td>14</td>
							<td></td>
						</tr>
						<tr>
							<th>49</th>
							<td>14</td>
							<td>15</td>
							<td></td>
						</tr>
					</tbody>
				</tr>
			</table>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
			</div>
		</div>
	</div>
</div>