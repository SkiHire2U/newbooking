<li id="<?php echo e($equip->id); ?>" class="equipment">
	<div class="row">
		<div class="col-md-9">
			<img class="img-ski" src="<?php echo e(url('/images/ski.jpg')); ?>">
			<!-- <img src="<?php echo e($equip->image_url); ?>"> -->
			<h3><?php echo e($equip->name); ?></h3>
			<p><?php echo e($equip->notes); ?></p>
		</div>
		<div class="col-md-3">
			<div class="prices-container">
				<?php if($chalet['discount']): ?>
				<span class="discount"> - <small><?php echo e($chalet['discount']); ?></small></span>
				<?php endif; ?>
				<div class="plain-prices prices" data-id="<?php echo e($equip->id); ?>">
					<ul>
					<?php $__currentLoopData = $equip->prices->A; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $price): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<?php echo $__env->make('partials._prices', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					</ul>
				</div>
				<div class="add-button-container">
					<a href="#" class="btn btn-primary" data-toggle="modal" data-target="#package-renter-modal-<?php echo e($equip->id); ?>" data-id="<?php echo e($equip->id); ?>">Add to Rack</a>
				</div>
			</div>
			<div class="modal fade" id="package-renter-modal-<?php echo e($equip->id); ?>" tabindex="-1" role="dialog" aria-labelledby="packageRenter">
				<div class="modal-dialog" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
							<h3 class="modal-title"><?php echo e($equip->name); ?></h3>
						</div>
						<div class="modal-body">
							<div class="row">
								<div class="form-wrapper col-md-8 col-md-offset-2">
								<?php echo Form::open(array('route' => 'addToRack', 'method' => 'POST', 'class' => 'rack-details', 'data-id' => $equip->id )); ?>

					            	<input type="text" class="form-control hidden" id="package-id">
						         	<div class="form-group">
						            	<?php echo e(Form::label('package_renter', 'Full Name:')); ?>

						            	<?php echo e(Form::text('package_renter', null, array('class' => 'renter-name form-control', 'required' => ''))); ?>

					          		</div>
					          		<div class="checkbox addon">
									    <label>
									    	<input name="addon[boots]" type="hidden" value="off">
									      	<input name="addon[boots]" class="boots-addon" data-id="<?php echo e($equip->id); ?>" type="checkbox">
											<img class="img-boots" src="<?php echo e(url('/images/boots.jpg')); ?>">Add Boots
									    </label>
									</div>
									<div class="checkbox addon">
									    <label>
									    	<input name="addon[helmet]" type="hidden" value="off">
									      	<input name="addon[helmet]" class="helmet-addon" data-id="<?php echo e($equip->id); ?>" type="checkbox">
									      	<img class="img-helmet" src="<?php echo e(url('/images/helmet.jpg')); ?>">Add Helmet
									    </label>
									</div>
									<div class="checkbox addon">
									    <label>
									    	<input name="addon[insurance]" type="hidden" value="off">
									      	<input name="addon[insurance]" class="insurance-addon" data-id="<?php echo e($equip->id); ?>" type="checkbox">
									      	Insurance
									    </label>
									</div>
									<div class="hidden">
										<?php echo e(Form::text('package_id', $equip->id)); ?>

										<?php echo e(Form::text('rent_days', $days, array('class' => 'rent-days'))); ?>

										<?php echo e(Form::text('rent_status', 'new')); ?>

									</div>
							        <div class="final-price" data-id="<?php echo e($equip->id); ?>">
							        	<div class="prices-container">
							        		<?php if($chalet['discount']): ?>
											<span class="discount"> - <small><?php echo e($chalet['discount']); ?></small></span>
											<?php endif; ?>
											<div class="plain-prices prices" data-id="<?php echo e($equip->id); ?>">
												<ul>
												<?php $__currentLoopData = $equip->prices->A; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $price): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
													<?php echo $__env->make('partials._prices', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
												</ul>
											</div>
											<div class="boots-prices prices" data-id="<?php echo e($equip->id); ?>">
												<ul>
												<?php $__currentLoopData = $equip->prices->B; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $day => $price): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
													<?php echo $__env->make('partials._prices', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
												</ul>
											</div>
										</div>
							        </div>
							    </div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
							<button type="submit" class="btn btn-primary">Continue</button>
						</div>
						<?php echo Form::close(); ?>

					</div>
				</div>
			</div>
		</div>
	</div>
</li>