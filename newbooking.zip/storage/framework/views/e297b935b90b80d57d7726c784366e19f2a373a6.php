<div class="menu-contianer">
	<div class="container">
		<nav class="admin-menu">
			<ul>
				<li><a href="/admin/">Home</a></li>
				<li><a href="/admin/bookings/">Booking</a></li>
				<li><a href="/admin/accommodations/">Accommodations</a></li>
				<li><a href="/admin/packages/">Packages and Addons</a></li>
			</ul>
		</nav>
	</div>
</div>