<?php $__env->startSection('styles'); ?>
    <?php echo Html::style('css/bootstrap-datetimepicker.min.css'); ?>

    <?php echo Html::style('/css/bootstrap-select.min.css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('title-bar'); ?>
    <?php echo $__env->make('partials._titlebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-7">
                <div class="section-details">
                    <h2>Start new booking</h2>
                    <p>To start a new booking, please complete the information below.</p>
                </div>
                <hr>
                <div class="new-boooking-wrapper clearfix">
                    <?php echo Form::open(array('route' => 'dateDetails', 'method' => 'POST', 'data-parsley-validate' => '')); ?>

                        <div class="form-section">
                            <h3>Accommodation Details</h3>
                            <p>Please select your accommodation or "Not Listed – Independent" if not found</p>
                            <div class="form-group">
                                <?php echo e(Form::label('chalet_id', 'Chalet')); ?>

                                <select id="chalet_id" name="chalet_id" class="col-md-12 custom-select selectpicker" data-show-subtext="true" data-live-search="true">
                                    <?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <?php if($operator->is_active == 1): ?>
                                    <?php $__currentLoopData = $operator->accommodations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <?php if($acc->is_active == 1): ?>
                                    <option value="<?php echo e($acc->id); ?>" data-subtext="<?php echo e($acc->operator->name); ?>" <?php echo e($acc->id == '1' ? 'selected="selected"' : ''); ?>><?php echo e($acc->name); ?></option>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                </select>
                            </div>
                            <div id="independent-info" class="hidden">
	                            <div class="form-group">
	                                <?php echo e(Form::label('chalet_name', 'Name of Accommodation')); ?>

	                                <?php echo e(Form::text('chalet_name', null, array('id' => 'chalet-name', 'class' => 'form-control', 'required' => ''))); ?>

	                            </div>
	                            <div class="form-group">
	                                <?php echo e(Form::label('chalet_address', 'Address')); ?>

	                                <?php echo e(Form::text('chalet_address', null, array('id' => 'chalet-address', 'class' => 'form-control', 'required' => ''))); ?>

	                            </div>
	                        </div>
                        </div>
                        <hr>
                        <div class="form-section">
                            <h3>Dates</h3>
                            <div class="form-group">
                                <?php echo e(Form::label('arrival_dtp', 'Arrival Date/Time')); ?>

                                <div class='input-group date' id='arrival_dtp'>
                                    <input name="arrival_dtp" type='text' class="form-control" required />
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('departure_dtp', 'Departure Date/Time')); ?>

                                <div class='input-group date' id='departure_dtp'>
                                    <input name="departure_dtp" type='text' class="form-control" required />
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                            </div>
                            <div class="form-group">
                                <?php echo e(Form::label('mountain_dtp', 'First day on Mountain')); ?>

                                <div class='input-group date' id='mountain_dtp'>
                                    <input name="mountain_dtp" type='text' class="form-control" required />
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <hr>
                        <?php echo e(Form::submit('Continue', array('class' => 'btn btn-success'))); ?>


                    <?php echo Form::close(); ?>

                </div>
            </div>
            <div class="col-md-4 col-md-offset-1">
                <?php echo $__env->make('partials._sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <?php echo Html::script('js/bootstrap-select.min.js'); ?>

    <?php echo Html::script('js/moment-with-locales.js'); ?>

    <?php echo Html::script('js/bootstrap-datetimepicker.min.js'); ?>

    <script type="text/javascript">
        jQuery(document).ready(function() {
           	checkChalet();

           	jQuery('#chalet_id').change(function() {
           		checkChalet();
           	});

            jQuery('#arrival_dtp').datetimepicker({
                format: 'DD-MM-YYYY HH:mm',
                stepping: 30,
                minDate: moment().endOf('hour'),
                showClear: true,
                sideBySide: true
            });
            jQuery('#departure_dtp').datetimepicker({
                format: 'DD-MM-YYYY HH:mm',
                stepping: 30,
                minDate: moment().endOf('hour'),
                useCurrent: false,
                sideBySide: true
            });
            jQuery('#mountain_dtp').datetimepicker({
                format: 'DD-MM-YYYY HH:mm',
                defaultDate: moment().add(1, 'day').hour(9).minute(0).second(0),
                stepping: 30,
                minDate: moment().add(1, 'day').hour(9).minute(0).second(0),
                useCurrent: false,
                sideBySide: true
            });
            jQuery("#arrival_dtp").on("dp.change", function (e) {
                var date = moment().set({
                    'year': moment(e.date).get('year'),
                    'month': moment(e.date).get('month'),
                    'date': moment(e.date).get('date'),
                    'hour': 9,
                    'minute': 0,
                    'second': 0,
                });
                jQuery('#mountain_dtp').data("DateTimePicker").minDate(date);
                jQuery('#departure_dtp').data("DateTimePicker").minDate(date);
                if(date != e.date) {
                    jQuery('#mountain_dtp').data("DateTimePicker").date(date);
                }
                /*
                var mtn = jQuery('#mountain_dtp').data("DateTimePicker").date();
                if(mtn) {
                    jQuery('#departure_dtp').data("DateTimePicker").minDate(mtn);
                } else {
                    jQuery('#departure_dtp').data("DateTimePicker").minDate(e.date);
                }
                jQuery('#mountain_dtp').data("DateTimePicker").minDate(date);
                */
            });
            jQuery("#departure_dtp").on("dp.change", function (e) {
                var mtn = jQuery('#mountain_dtp').data("DateTimePicker").date();
                if(mtn) {
                    jQuery('#arrival_dtp').data("DateTimePicker").maxDate(mtn);
                } else {
                    jQuery('#arrival_dtp').data("DateTimePicker").maxDate(e.date);
                }
                jQuery('#mountain_dtp').data("DateTimePicker").maxDate(e.date);
            });
            jQuery("#mountain_dtp").on("dp.change", function (e) {
                //jQuery('#arrival_dtp').data("DateTimePicker").maxDate(e.date);
                jQuery('#departure_dtp').data("DateTimePicker").minDate(e.date);
            });

        });

		function checkChalet() {
	        var val = jQuery('#chalet_id').val();
	        if( val == '1') {
	            jQuery('#independent-info').removeClass('hidden');
	            jQuery('#chalet-name').val('');
	            jQuery('#chalet-address').val('');
	        } else {
	            jQuery('#independent-info').addClass('hidden');
	            jQuery('#chalet-name').val('null');
	            jQuery('#chalet-address').val('null');
	        }
		}

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>