<div class="equipments-container">
    <span><strong><?php echo e($packageModel->getPackageName($package['package_id'])); ?></strong></span>
    <?php if($packageModel->getPackageLevel($package['package_id'])): ?>
    <span><strong><?php echo e($packageModel->getPackageLevel($package['package_id'])); ?></strong></span>
    <?php endif; ?>
    <span>Duration: <?php echo e($package['rent_days']); ?> <?php echo e(($package['rent_days'] == 1) ? 'day' : 'days'); ?></span>
    <span>Boots: <?php echo e(($package['addon']['boots'] == 'on') ? 'Yes' : 'No'); ?></span>
    <span>
    	Helmet: <?php echo e(($package['addon']['helmet'] == 'on') ? 'Yes' : 'No'); ?>

    	<?php if( (int) $package['renter_age'] <= 16 && $package['renter_age'] != null && $package['addon']['helmet'] == 'on'): ?>
    	<small class="free-helmet">FREE! *</small>
    	<?php endif; ?>
    </span>
    <span>Insurance: <?php echo e(($package['addon']['insurance'] == 'on') ? 'Yes' : 'No'); ?></span>
</div> 