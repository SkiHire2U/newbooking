<?php $__env->startSection('title-bar'); ?>
	<?php echo $__env->make('partials._adminMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="/css/admin.css">
<link rel="stylesheet" type="text/css" href="/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="table-container">
		<table class="table webee-table" id="dataTable">
			<thead>
				<th>Date Created</th>
				<!-- <th>Reference Number</th> -->
				<th>Party Leader Information</th>
				<!-- <th>Members</th> -->
				<th>First Day on Mountain</th>
				<th>Arrival/Departure Date</th>
				<th></th>
			</thead>
			<tbody>
			<?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<tr>
					<td><?php echo e($booking->created_at); ?></td>
					<!-- <td><?php echo e($booking->reference_number); ?></td> -->
					<td><strong><?php echo e($booking->party_leader); ?></strong> <br>
						<?php echo e($booking->chalet_name); ?> <br>
						No. of People: <?php echo e($booking->rentals->count()); ?><br>
						REF #: <?php echo e($booking->reference_number); ?>

					</td>
					<!-- <td><?php echo e($booking->rentals->count()); ?></td> -->
					<td><?php echo e($booking->mountain_datetime); ?></td>
					<td>
						<?php echo e($booking->arrival_datetime); ?><br>
						<?php echo e($booking->departure_datetime); ?>

					</td>
					<td>
						<a href="<?php echo e(route('booking', $booking->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-eye"></i></a>
						<a href="#" class="btn btn-danger btn-icon" data-toggle="modal" data-target="#remove-booking-modal" data-id="<?php echo e($booking->id); ?>"><i class="glyphicon glyphicon-trash" aria-hidden="true"></i></a>
						<div class="hidden">
							<?php echo Form::open(array('route' => array('booking.delete', $booking->id), 'method' => 'POST', 'class' => 'remove-booking', 'data-id' => $booking->id )); ?>

							<div class="hidden">
								<?php echo e(Form::text('booking_id', $booking->id, array('readonly' => ''))); ?>

							</div>
							<?php echo Form::close(); ?>

						</div>
					</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</tbody>
		</table>
	</div>
</div>
<div class="modal fade" id="remove-booking-modal" tabindex="-1" role="dialog" aria-labelledby="removeRenter">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
				<h4 class="modal-title" id="removal-modal-title">Delete Booking?</h4>
			</div>
			<div class="modal-body">
				<input type="text" class="form-control hidden" id="remove-booking">
		        <p id="removal-body-text">Are you sure you want to delete this booking?</p>
			</div>
			<div class="modal-footer">
				<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
				<button type="button" class="btn btn-primary" id="remove-booking-btn">Continue</button>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function() {
		jQuery('#dataTable').DataTable({
			"order": [[ 0, "desc" ]],
			"pageLength": 50
		});

		jQuery('#remove-booking-modal').on('show.bs.modal', function (event) {
            var button = jQuery(event.relatedTarget);
            var booking = button.data('id');
            var modal = jQuery(this);

            modal.find('#remove-booking').val(booking);
        });

		jQuery('#remove-booking-btn').click(function (e) {
            e.preventDefault();
            var id = jQuery('#remove-booking').val();
            jQuery('.remove-booking[data-id="' + id + '"]').submit();
        });
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>