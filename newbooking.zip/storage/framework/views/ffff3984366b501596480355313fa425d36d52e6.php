<?php $__env->startSection('title-bar'); ?>
	<?php echo $__env->make('partials._titlebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
        	<div class="col-md-8">
        		<div class="section-details">
                    <h2>Your rentals</h2>
                </div>
            </div>
            <div class="col-md-4">

            </div> 
        </div>
        <div class="row">
        	<div class="col-md-12">
        		<div class="alert alert-info" role="alert">
        			<p><strong>SAVE EACH PACKAGE ONE AT A TIME.</strong></p>
					<p>There's no rush, start filling in details for any package you like but <strong>remember to press 'Save' for that package to avoid losing your inputs</strong>.</p>
                    <p>To select a new package, kindly delete the package and click on Add New Package. Please note that this action will also remove Personal Details and Measurements input.</p>
				</div>
        	</div>
        </div>
        <div class="row">
        	<div class="col-md-12">
        		<div class="rental-information-table">
        			<table class="table table-bordered table-hover">
        				<thead>
        					<tr>
                                <th class="iteration"></th>
	        					<th>Personal Details</th>
	        					<th>Measurements</th>
	        					<th class="equipments">Equipment</th>
	        					<th class="price">Price</th>
	        					<th class="action"></th>
	        				</tr>
        				</thead>
        				<tbody>
                            <?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                            <?php if($package['rent_status'] == 'new'): ?>
        					<tr class="warning">
                                <?php echo Form::open(array('route' => array('saveRenter', $package['package_renter']), 'method' => 'POST', 'class' => 'form-renter-info')); ?>

                                <th class="iteration"><?php echo e($loop->iteration); ?></th>
        						<td>
                                    <div class="form-input-container">
                                        <div class="form-group">
                                            <?php echo e(Form::label('package_renter', 'Full Name:')); ?>

                                            <?php echo e(Form::text('package_renter', $package['package_renter'], array('class' => 'renter-name form-control', 'required' => ''))); ?>

                                        </div>
                                        <div class="form-group">
                                            <?php echo e(Form::label('renter_age', 'Age:')); ?>

                                            <?php echo e(Form::select('renter_age', $select['age'], null, array('class' => 'renter-age form-control', 'required' => ''))); ?>

                                        </div>
                                        <div class="form-group">
                                            <?php echo e(Form::label('renter_sex', 'Sex:')); ?>

                                            <?php echo e(Form::select('renter_sex', array('male' => 'Male', 'female' => 'Female'), null, array('class' => 'renter-sex form-control', 'required' => ''))); ?>

                                        </div>
                                        <div class="form-group">
                                            <?php echo e(Form::label('renter_notes', 'Notes')); ?><span> (optional)</span>
                                            <?php echo e(Form::text('renter_notes', '', array('class' => 'renter-notes form-control'))); ?>

                                        </div>
                                    </div>
                                </td>
        						<td>
                                    <div class="form-input-container">
                                        <div class="form-input-container">
                                            <div class="form-group">
                                                <?php echo e(Form::label('renter_ability', 'Ability:')); ?>

                                                <?php echo e(Form::select('renter_ability', $select['level'], null, array('class' => 'renter-abiity form-control', 'required' => ''))); ?>

                                            </div>
                                            <div class="form-group">
                                                <?php echo e(Form::label('renter_height', 'Height (in cm):')); ?>

                                                <?php echo e(Form::number('renter_height', null, array('class' => 'renter-height form-control', 'required' => ''))); ?>

                                            </div>
                                            <div class="form-group">
                                                <?php echo e(Form::label('renter_weight', 'Weight (in kg):')); ?>

                                                <?php echo e(Form::number('renter_weight', null, array('class' => 'renter-weight form-control', 'required' => ''))); ?>

                                            </div>
                                            <div class="form-group">
                                                <?php echo e(Form::label('renter_foot', 'Foot Size (in UK):')); ?>

                                                <?php echo e(Form::select('renter_foot', $select['foot'], null, array('class' => 'renter-foot form-control', 'required' => ''))); ?>

                                                <a href="#" data-toggle="modal" data-target="#foot-size-conversion-table"><small>Foot Size Conversion Table</small></a>
                                                <?php echo $__env->make('partials._footsize', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
        						<td>
                                    <div class="equipments-container">
                                        <span><strong><?php echo e($packageModel->getPackageName($package['package_id'])); ?></strong></span>
                                        <?php if($packageModel->getPackageLevel($package['package_id'])): ?>
                                        <span><strong><?php echo e($packageModel->getPackageLevel($package['package_id'])); ?></strong></span>
                                        <?php endif; ?>
                                        <span>Duration: <?php echo e($package['rent_days']); ?> <?php echo e(($package['rent_days'] == 1) ? 'day' : 'days'); ?></span>
                                        <span>Boots: <?php echo e(($package['addon']['boots'] == 'on') ? 'Yes' : 'No'); ?></span>
                                        <span>Helmet: <?php echo e(($package['addon']['helmet'] == 'on') ? 'Yes' : 'No'); ?></span>
                                        <span>Insurance: <?php echo e(($package['addon']['insurance'] == 'on') ? 'Yes' : 'No'); ?></span>
                                    </div> 
                                </td>
        						<td>
                                    <div class="rentals-prices-container">
                                        <?php if($chalet['discount']): ?>
                                        <span class="price">&euro; <?php echo e(number_format($prices[$package['package_renter']]['discounted'], 2, '.', ',')); ?></span>
                                        <span class="price strike"><small>&euro; <?php echo e(number_format($prices[$package['package_renter']]['originalAmount'], 2, '.', ',')); ?></small></span>
                                        <span class="discount-amount">Less: ( - &euro; <small><?php echo e(number_format($prices[$package['package_renter']]['discountAmount'], 2, '.', ',')); ?></small> )</span>
                                        <?php else: ?>
                                        <span class="price">&euro; <?php echo e(number_format($prices[$package['package_renter']]['originalAmount'], 2, '.', ',')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </td>
        						<td>
                                    <div class="hidden">
                                        <?php echo e(Form::text('package_id', $package['package_id'])); ?>

                                        <?php echo e(Form::text('rent_days', $package['rent_days'])); ?>

                                        <?php echo e(Form::text('addon[boots]', $package['addon']['boots'])); ?>

                                        <?php echo e(Form::text('addon[helmet]', $package['addon']['helmet'] )); ?>

                                        <?php echo e(Form::text('addon[insurance]', $package['addon']['insurance'])); ?>

                                        <?php echo e(Form::text('rent_status', 'saved')); ?>

                                    </div>
        							<button type="submit" class="btn btn-block btn-success">Save</button>
        							<a href="#" class="btn btn-block btn-danger" data-toggle="modal" data-target="#remove-from-rack-modal" data-id="<?php echo e($package['package_renter']); ?>">Delete</a>
        						</td>
                                <?php echo Form::close(); ?>

        					</tr>
                            <?php elseif($package['rent_status'] == 'edit'): ?>
                            <tr class="danger">
                                <?php echo Form::open(array('route' => array('saveRenter', $package['package_renter']), 'method' => 'POST', 'class' => 'form-renter-info')); ?>

                                <th class="iteration"><?php echo e($loop->iteration); ?></th>
                                <td>
                                    <div class="form-input-container">
                                        <div class="form-group">
                                            <?php echo e(Form::label('package_renter', 'Full Name:')); ?>

                                            <?php echo e(Form::text('package_renter', $package['package_renter'], array('class' => 'renter-name form-control', 'required' => ''))); ?>

                                        </div>
                                        <div class="form-group">
                                            <?php echo e(Form::label('renter_age', 'Age:')); ?>

                                            <?php echo e(Form::select('renter_age', $select['age'], $package['renter_age'], array('class' => 'renter-age form-control', 'required' => ''))); ?>

                                        </div>
                                        <div class="form-group">
                                            <?php echo e(Form::label('renter_sex', 'Sex:')); ?>

                                            <?php echo e(Form::select('renter_sex', array('male' => 'Male', 'female' => 'Female'), $package['renter_sex'], array('class' => 'renter-sex form-control', 'required' => ''))); ?>

                                        </div>
                                        <div class="form-group">
                                            <?php echo e(Form::label('renter_notes', 'Notes')); ?><span> (optional)</span>
                                            <?php echo e(Form::text('renter_notes', ($package['renter_notes'] != '') ? $package['renter_notes'] : '', array('class' => 'renter-notes form-control'))); ?>

                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="form-input-container">
                                        <div class="form-input-container">
                                            <div class="form-group">
                                                <?php echo e(Form::label('renter_ability', 'Ability:')); ?>

                                                <?php echo e(Form::select('renter_ability', $select['level'], $package['renter_ability'], array('class' => 'renter-abiity form-control', 'required' => ''))); ?>

                                            </div>
                                            <div class="form-group">
                                                <?php echo e(Form::label('renter_height', 'Height (in cm):')); ?>

                                                <?php echo e(Form::number('renter_height', $package['renter_height'], array('class' => 'renter-height form-control', 'required' => ''))); ?>

                                            </div>
                                            <div class="form-group">
                                                <?php echo e(Form::label('renter_weight', 'Weight (in kg):')); ?>

                                                <?php echo e(Form::number('renter_weight', $package['renter_weight'], array('class' => 'renter-weight form-control', 'required' => ''))); ?>

                                            </div>
                                            <div class="form-group">
                                                <?php echo e(Form::label('renter_foot', 'Foot Size (in UK):')); ?>

                                                <?php echo e(Form::select('renter_foot', $select['foot'], $package['renter_foot'], array('class' => 'renter-foot form-control', 'required' => ''))); ?>

                                                <a href="#" data-toggle="modal" data-target="#foot-size-conversion-table"><small>Foot Size Conversion Table</small></a>
                                                <?php echo $__env->make('partials._footsize', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="equipments-container">
                                        <span><strong><?php echo e($packageModel->getPackageName($package['package_id'])); ?></strong></span>
                                        <?php if($packageModel->getPackageLevel($package['package_id'])): ?>
                                        <span><strong><?php echo e($packageModel->getPackageLevel($package['package_id'])); ?></strong></span>
                                        <?php endif; ?>
                                        <span>Duration: <?php echo e($package['rent_days']); ?> <?php echo e(($package['rent_days'] == 1) ? 'day' : 'days'); ?></span>
                                        <span>Boots: <?php echo e(($package['addon']['boots'] == 'on') ? 'Yes' : 'No'); ?></span>
                                        <span>Helmet: <?php echo e(($package['addon']['helmet'] == 'on') ? 'Yes' : 'No'); ?></span>
                                        <span>Insurance: <?php echo e(($package['addon']['insurance'] == 'on') ? 'Yes' : 'No'); ?></span>
                                    </div> 
                                </td>
                                <td>
                                    <div class="rentals-prices-container">
                                        <?php if($chalet['discount']): ?>
                                        <span class="price">&euro; <?php echo e(number_format($prices[$package['package_renter']]['discounted'], 2, '.', ',')); ?></span>
                                        <span class="price strike"><small>&euro; <?php echo e(number_format($prices[$package['package_renter']]['originalAmount'], 2, '.', ',')); ?></small></span>
                                        <span class="discount-amount">Less: ( - &euro; <small><?php echo e(number_format($prices[$package['package_renter']]['discountAmount'], 2, '.', ',')); ?></small> )</span>
                                        <?php else: ?>
                                        <span class="price">&euro; <?php echo e(number_format($prices[$package['package_renter']]['originalAmount'], 2, '.', ',')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <div class="hidden">
                                        <?php echo e(Form::text('package_id', $package['package_id'])); ?>

                                        <?php echo e(Form::text('rent_days', $package['rent_days'])); ?>

                                        <?php echo e(Form::text('addon[boots]', $package['addon']['boots'])); ?>

                                        <?php echo e(Form::text('addon[helmet]', $package['addon']['helmet'] )); ?>

                                        <?php echo e(Form::text('addon[insurance]', $package['addon']['insurance'])); ?>

                                        <?php echo e(Form::text('rent_status', 'saved')); ?>

                                    </div>
                                    <button type="submit" class="btn btn-block btn-success">Save</button>
                                    <a href="#" class="btn btn-block btn-danger" data-toggle="modal" data-target="#remove-from-rack-modal" data-id="<?php echo e($package['package_renter']); ?>">Delete</a>
                                </td>
                                <?php echo Form::close(); ?>

                            </tr>
                            <?php else: ?>
                            <tr class="success">
                                <?php echo Form::open(array('route' => array('editRenter', $package['package_renter']), 'method' => 'POST', 'class' => 'form-renter-info')); ?>

                                <th class="iteration"><?php echo e($loop->iteration); ?></th>
                                <td>
                                    <h4><?php echo e($package['package_renter']); ?></h4>
                                    <p>Age: <strong><?php echo e($select['age'][$package['renter_age']]); ?></strong></p>
                                    <p>Sex: <strong><?php echo e($package['renter_sex']); ?></strong></p>
                                    <?php if($package['renter_notes'] != ''): ?>
                                    <p>Notes: <stong><?php echo e($package['renter_notes']); ?></stong></p>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <p>Ability: <strong><?php echo e($select['level'][$package['renter_ability']]); ?></strong></p>
                                    <p>Height (in cm): <strong><?php echo e($package['renter_height']); ?></strong></p>
                                    <p>Weight (in kg): <strong><?php echo e($package['renter_weight']); ?></strong></p>
                                    <p>Foot Size (in UK): <strong><?php echo e($select['foot'][$package['renter_foot']]); ?></strong></p>
                                </td>
                                <td>
                                    <div class="equipments-container">
                                        <span><strong><?php echo e($packageModel->getPackageName($package['package_id'])); ?></strong></span>
                                        <span><strong><?php echo e($packageModel->getPackageLevel($package['package_id'])); ?></strong></span>
                                        <span>Duration: <?php echo e($package['rent_days']); ?> <?php echo e(($package['rent_days'] == 1) ? 'day' : 'days'); ?></span>
                                        <span>Boots: <?php echo e(($package['addon']['boots'] == 'on') ? 'Yes' : 'No'); ?></span>
                                        <span>Helmet: <?php echo e(($package['addon']['helmet'] == 'on') ? 'Yes' : 'No'); ?></span>
                                        <span>Insurance: <?php echo e(($package['addon']['insurance'] == 'on') ? 'Yes' : 'No'); ?></span>
                                    </div> 
                                </td>
                                <td>
                                    <div class="rentals-prices-container">
                                        <?php if($chalet['discount']): ?>
                                        <span class="price">&euro; <?php echo e(number_format($prices[$package['package_renter']]['discounted'], 2, '.', ',')); ?></span>
                                        <span class="price strike"><small>&euro; <?php echo e(number_format($prices[$package['package_renter']]['originalAmount'], 2, '.', ',')); ?></small></span>
                                        <span class="discount-amount">Less: ( - &euro; <small><?php echo e(number_format($prices[$package['package_renter']]['discountAmount'], 2, '.', ',')); ?></small> )</span>
                                        <?php else: ?>
                                        <span class="price">&euro; <?php echo e(number_format($prices[$package['package_renter']]['originalAmount'], 2, '.', ',')); ?></span>
                                        <?php endif; ?>
                                    </div>
                                </td>
                                <td>
                                    <button type="submit" class="btn btn-block btn-success">Edit</button>
                                    <a  href="#" class="btn btn-block btn-danger" data-toggle="modal" data-target="#remove-from-rack-modal" data-id="<?php echo e($package['package_renter']); ?>">Delete</a>
                                </td>
                                <?php echo Form::close(); ?>

                            </tr>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        				</tbody>
        				<tfoot>
        					<tr>
                                <td></td>
	        					<td class="add-new-package-cell"><a href="<?php echo e(route('equipments')); ?>" class="btn btn-primary">Add new package</a></td>
	        					<td colspan="2" class="total-cell">Total</td>
	        					<td>
                                    <?php if($chalet['discount']): ?>
                                    <span class="total-price">&euro; <?php echo e(number_format($prices['totalDiscounted'], 2, '.', ',')); ?></span>
                                    <span class="total-price strike"><small>&euro; <?php echo e(number_format($prices['total'], 2, '.', ',')); ?></small></span>
                                    <?php else: ?>
                                    <span class="total-price">&euro; <?php echo e(number_format($prices['total'], 2, '.', ',')); ?></span>
                                    <?php endif; ?>
                                </td>
	        					<td></td>
	        				</tr>
        				</tfoot>
        			</table>
        		</div>
        	</div>
        </div>
        <div class="row">
            <div class="col-md-10">
                <div class="alert alert-info" role="alert">
                    <p>Please complete and save all the packages above to proceed.</p>
                </div>
                
            </div>
            <div class="col-md-2">
                <?php if($button): ?>
                <a href="<?php echo e(route('details')); ?>" class="btn btn-success btn-lg pull-right">Continue</a>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="modal fade" id="remove-from-rack-modal" tabindex="-1" role="dialog" aria-labelledby="removeRenter">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    <h4 class="modal-title" id="removal-modal-title">REMOVE PACKAGE FOR: %renter%</h4>
                </div>
                <div class="modal-body">
                    <form>
                        <input type="text" class="form-control hidden" id="remove-renter">
                    </form>
                    <p id="removal-body-text">Are you sure you would like to remove the package for <strong>%renter%</strong> from the rentals?</p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                    <button type="button" class="btn btn-primary" id="remove-from-rack-btn">Continue</button>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript">
    jQuery(document).ready(function() {
        jQuery('#remove-from-rack-modal').on('show.bs.modal', function (event) {
            var button = jQuery(event.relatedTarget);
            var renter = button.data('id');
            var modal = jQuery(this);

            modal.find('#removal-modal-title').text(renterReplace(modal.find('#removal-modal-title').text(), renter));
            modal.find('#removal-body-text').text(renterReplace(modal.find('#removal-body-text').text(), renter));
            modal.find('#remove-renter').val(renter);
        });

        jQuery('#remove-from-rack-btn').click(function (e) {
            e.preventDefault();
            var id = jQuery('#remove-renter').val();
            jQuery('.remove-from-rack[data-id="' + id + '"]').submit();
        });
    });

    function renterReplace(originalString, newString) {
        return originalString.replace(/%renter%/, newString);
    }
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>