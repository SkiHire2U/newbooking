<?php $__env->startSection('title-bar'); ?>
	<?php echo $__env->make('partials._adminMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="/css/admin.css">
<link rel="stylesheet" type="text/css" href="/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<h2>Booking Information</h2>
	<div class="booking-data">
		<p><strong>Party Leader: </strong> <?php echo e($booking->party_leader); ?></p>
		<p><strong>Party Email: </strong> <?php echo e($booking->party_email); ?></p>
		<p><strong>Party Mobile: </strong> <?php echo e($booking->party_mobile); ?></p>
		<p><strong>Reference Number: </strong> <?php echo e($booking->reference_number); ?></p>
		<p><strong>Arrival Date: </strong> <?php echo e($booking->arrival_datetime); ?></p>
		<p><strong>Departure Date: </strong> <?php echo e($booking->departure_datetime); ?></p>
		<p><strong>First Day on Mountain: </strong> <?php echo e($booking->mountain_datetime); ?></p>
	</div>
</div>
<div class="container">
	<h3>Members</h3>
	<div class="table-container">
		<table class="table webee-table" id="dataTable">
			<thead>
				<th>Name</th>
				<th>Personal Details</th>
				<th>Measurements</th>
				<th>Contact Info</th>
				<th>Members</th>
			</thead>
			<tbody>
			<?php $__currentLoopData = $booking->rentals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rental): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<tr>
					<td><?php echo e($rental->name); ?></td>
					<td></td>
					<td></td>
					<td></td>
					<td></td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</tbody>
		</table>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function() {
		/*
		jQuery('#dataTable').DataTable({
			"order": [[ 1, "desc" ]]
		});
		*/
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>