<?php $__env->startSection('title-bar'); ?>
	<?php echo $__env->make('partials._adminMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="/css/admin.css">
<link rel="stylesheet" type="text/css" href="/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="table-container">
		<table class="table webee-table" id="dataTable">
			<thead>
				<th>Date Created</th>
				<th>Reference Number</th>
				<th>Party Leader</th>
				<th>Contact Info</th>
				<th>Members</th>
				<th>Arrival/Departure Date</th>
				<th></th>
			</thead>
			<tbody>
			<?php $__currentLoopData = $bookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<tr>
					<td><?php echo e($booking->created_at); ?></td>
					<td><?php echo e($booking->reference_number); ?></td>
					<th><?php echo e($booking->party_leader); ?></th>
					<td>
						<?php echo e($booking->party_email); ?> <br>
						<?php echo e($booking->party_mobile); ?>

					</td>
					<td><?php echo e($booking->rentals->count()); ?></td>
					<td>
						<?php echo e($booking->arrival_datetime); ?><br>
						<?php echo e($booking->departure_datetime); ?>

					</td>
					<td>
						<a href="<?php echo e(route('booking', $booking->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-eye"></i></a>
					</td>
				</tr>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</tbody>
		</table>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function() {
		jQuery('#dataTable').DataTable({
			"order": [[ 0, "desc" ]]
		});
	});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>