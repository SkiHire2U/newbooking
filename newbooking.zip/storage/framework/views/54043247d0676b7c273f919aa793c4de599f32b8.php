<li class="<?php echo e($day); ?> price">
	<?php if($chalet['discount']): ?>
	<span class="final">&euro; <small><?php echo e(number_format(($price - ($price * ((int) $chalet['discount'] / 100) )), 2, '.', ',')); ?></small></span>
	<span class="price-small strike">&euro; <small><?php echo e(number_format($price, 2, '.', ',')); ?></small></span>
	<span class="discount-amount">Less: ( - &euro; <small><?php echo e(number_format($price * ((int) $chalet['discount'] / 100), 2, '.', ',')); ?></small> )</span>
	<?php else: ?>
	<span class="final">&euro; <small><?php echo e(number_format($price, 2, '.', ',')); ?></small></span>
	<?php endif; ?>
</li>