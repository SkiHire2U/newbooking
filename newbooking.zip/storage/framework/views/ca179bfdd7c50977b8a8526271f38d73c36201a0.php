<div style="background:#EEE;width:100%;padding:70px 0">
	<div style="max-width:600px;width:100%;margin:0 auto;">
		<div>
			<p style="margin-top:0;text-align:center">
				<img width="300" src="http://skihire2u.com/wp-content/uploads/2016/09/SkiHire2U-logo-dark-red-new.png" alt="Skihire2u">
			</p>
		</div>
		<table border="0" cellpadding="0" cellspacing="0" width="600">
			<tbody>
				<tr>
					<td align="center" valign="top">
						<table border="0" cellpadding="0" cellspacing="0" width="600" style="background-color:#242223;border-radius:3px 3px 0 0!important;color:#ffffff;border-bottom:0;font-weight:bold;line-height:100%;vertical-align:middle;">
							<tbody>
								<tr>
									<td style="padding:36px 48px;display:block">
										<h1 style="color:#ffffff;font-family:Arial,sans-serif;font-size:30px;font-weight:300;line-height:150%;margin:0;text-align:left">Booking Updated</h1>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
				<tr>
					<td align="center" valign="top">
						<table border="0" cellpadding="0" cellspacing="0" width="600">
							<tbody>
								<tr>
									<td valign="top" id="m_2471269498227967455body_content" style="background-color:#fdfdfd">
										<table border="0" cellpadding="20" cellspacing="0" width="100%">
											<tbody>
												<tr>
													<td valign="top" style="padding:30px 30px 15px;font-family:Arial,sans-serif;">
														<p>Hello <?php echo e($name); ?>,</p>
														<p>Your booking was updated. Please see the details below:</p>
													</td>
												</tr>
												<tr>
													<td valign="top" style="padding:10px 30px">
														<table cellspacing="0" cellpadding="6" style="width:100%;color:#333;border:1px solid #e4e4e4" border="1">
															<tbody>
																<tr>
																	<th style="text-align:left;vertical-align:middle;padding:12px;font-family:Arial,sans-serif;">
																		Accommodation:
																	</th>
																	<td style="text-align:left;vertical-align:middle;padding:12px;font-family:Arial,sans-serif;">
																		<?php echo e($accommodation); ?>

																	</td>
																</tr>
																<tr>
																	<th style="text-align:left;vertical-align:middle;padding:12px;font-family:Arial,sans-serif;">
																		Arrival:
																	</th>
																	<td style="text-align:left;vertical-align:middle;padding:12px;font-family:Arial,sans-serif;">
																		<?php echo e($arrival); ?>

																	</td>
																</tr>
																<tr>
																	<th style="text-align:left;vertical-align:middle;padding:12px;font-family:Arial,sans-serif;">
																		Departure:
																	</th>
																	<td style="text-align:left;vertical-align:middle;padding:12px;font-family:Arial,sans-serif;">
																		<?php echo e($departure); ?>

																	</td>
																</tr>
																<tr>
																	<th style="text-align:left;vertical-align:middle;padding:12px;font-family:Arial,sans-serif;">
																		Reference Code:
																	</th>
																	<td style="text-align:left;vertical-align:middle;padding:12px;font-family:Arial,sans-serif;">
																		<?php echo e($reference); ?>

																	</td>
																</tr>
															</tbody>
														</table>
													</td>
												</tr>
												<tr>
													<td valign="top" style="padding:10px 30px">
														<table cellspacing="0" cellpadding="6" style="width:100%;color:#333;border:1px solid #e4e4e4" border="1">
															<thead>
																<tr>
																	<th style="text-align:left;vertical-align:middle;padding:12px;font-family:Arial,sans-serif;">
																		Name
																	</th>
																	<th style="text-align:left;vertical-align:middle;padding:12px;font-family:Arial,sans-serif;">
																		Details
																	</th>
																	<th style="text-align:left;vertical-align:middle;padding:12px;font-family:Arial,sans-serif;">
																		Package and Addons
																	</th>
																</tr>
															</thead>
															<tbody>
																<?php $__currentLoopData = $packages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
																<tr>
																	<td style="text-align:left;vertical-align:middle;padding:12px;font-family:Arial,sans-serif;">
																		<strong><?php echo e($package['package_renter']); ?></strong>
																		<p style="margin:0;"><?php echo e($select['age'][$package['renter_age']]); ?></p>
																		<p style="margin:0;"><?php echo e($package['renter_sex']); ?></p>
																		<?php if($package['renter_notes']): ?>
																		<p style="margin:0;">Notes: <strong><?php echo e($package['renter_notes']); ?></strong></p>
																		<?php endif; ?>
																	</td>
																	<td style="text-align:left;vertical-align:middle;padding:12px;font-family:Arial,sans-serif;">
																		<p style="margin:0;">Ability: <strong><?php echo e($select['level'][$package['renter_ability']]); ?></strong></p>
												                        <p style="margin:0;">Height: <strong><?php echo e($select['height'][$package['renter_height']]); ?></strong></p>
												                        <p style="margin:0;">Weight: <strong><?php echo e($select['weight'][$package['renter_weight']]); ?></strong></p>
												                        <p style="margin:0;">Foot Size: <strong><?php echo e($select['foot'][$package['renter_foot']]); ?></strong></p>
																	</td>
																	<td>
																		<p style="margin:0;"><strong><?php echo e($package['package_name']); ?></strong></p>
																		<?php if($package['package_level']): ?>
																		<p style="margin:0;"><strong><?php echo e($package['package_level']); ?></strong></p>
																		<?php endif; ?>
																		<p style="margin:0;">Duration: <strong><?php echo e($package['rent_days']); ?> <?php echo e(($package['rent_days'] == 1) ? 'day' : 'days'); ?></strong></p>
																		<p style="margin:0;">Addons:</p>
																		<?php if($package['addon']['boots'] == 'on'): ?>
																		<p style="margin:0;"><strong>Boots</strong></p>
																		<?php endif; ?>
																		<?php if($package['addon']['helmet'] == 'on'): ?>
																		<p style="margin:0;">
																			<strong>Helmet</strong>
												                        	<?php if( (int) $package['renter_age'] <= 3 || $package['package_type'] == 'Child'): ?>
																	    	<small class="free-helmet">(FREE!)</small>
																	    	<?php endif; ?>
																		</p>
																		<?php endif; ?>
																		<?php if($package['addon']['insurance'] == 'on'): ?>
																		<p style="margin:0;"><strong>Insurance</strong></p>
																		<?php endif; ?>
																		<?php if($package['addon']['boots'] == 'off' && $package['addon']['helmet'] == 'off' && $package['addon']['insurance'] == 'off'): ?>
																		<p style="margin:0;"><strong>N/A</strong></p>
																		<?php endif; ?>
																	</td>
																</tr>
																<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
															</tbody>
														</table>
													</td>
												</tr>
												<tr>
													<td valign="top" style="padding:10px 30px;font-family:Arial,sans-serif;">
														<p>If you wish to revisit your packages, go to this link and input your email and reference code: <a href="http://newbooking.skihire2u.com/" target="_blank">http://newbooking.skihire2u.com/</a></p>
														<p>We will contact you shortly before your arrival to arrange a convenient time to come and fit all your equipment so you can now sit back, relax and enjoy your holiday.</p>
													</td>
												</tr>
												<tr>
													<td valign="top" style="padding:10px 30px 30px;font-family:Arial,sans-serif;">
														<p>See you soon,</p>
														<h2 style="margin:0;">SkiHire2U</h2>
														<small>Sit back, relax and we'll come to you</small>
													</td>
												</tr>
											</tbody>
										</table>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
				<tr>
					<td align="center" valign="top">
						<table border="0" cellpadding="0" cellspacing="0" width="600" style="background-color:#242223;border-radius:3px 3px 0 0!important;color:#ffffff;border-bottom:0;vertical-align:middle;">
							<tbody>
								<tr>
									<td style="padding:36px 48px;display:block;text-align:center;">
										<small style="color:#ffffff;font-family:Arial,sans-serif;">SkiHire2U.com &copy; 2016</small>
									</td>
								</tr>
							</tbody>
						</table>
					</td>
				</tr>
			</tbody>
		</table>
	</div>
</div>