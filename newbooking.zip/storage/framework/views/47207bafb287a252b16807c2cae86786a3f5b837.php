<?php $__env->startSection('title-bar'); ?>
	<?php echo $__env->make('partials._adminMenu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('styles'); ?>
<link rel="stylesheet" type="text/css" href="/css/admin.css">
<link rel="stylesheet" type="text/css" href="/css/jquery.dataTables.min.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Accommodations</h2>
    <div class="admin-button-container">
		<a href="#" class="btn btn-default btn-icon" data-toggle="modal" data-target="#add-operator-modal" title="Add"><i class="fa fa-plus"></i>Add Operator</a>
		<div class="modal fade" id="add-operator-modal" tabindex="-1" role="dialog" aria-labelledby="addOperator">
			<div class="modal-dialog" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						<h3 class="modal-title">Add Operator</h3>
					</div>
					<div class="modal-body">
						<div class="row">
							<div class="form-wrapper col-md-8 col-md-offset-2">
							<?php echo Form::open(array('route' => 'operator.store', 'method' => 'PUT', 'class' => 'add-operator' )); ?>

								<div class="form-group">
					            	<?php echo e(Form::label('operator_name', 'Operator Name:')); ?>

					            	<?php echo e(Form::text('operator_name', null, array('class' => 'operator-name form-control', 'required' => ''))); ?>

				          		</div>
				          		<div class="form-group">
					            	<?php echo e(Form::label('web_address', 'Web Address:')); ?>

					            	<?php echo e(Form::text('web_address', null, array('class' => 'web-address form-control'))); ?>

				          		</div>
				          		<div class="form-group">
					            	<?php echo e(Form::label('postal_address', 'Postal Address:')); ?>

					            	<?php echo e(Form::text('postal_address', null, array('class' => 'postal-address form-control'))); ?>

				          		</div>
				          		<div class="form-group">
					            	<?php echo e(Form::label('notes', 'Notes:')); ?>

					            	<?php echo e(Form::text('notes', null, array('class' => 'notes form-control'))); ?>

				          		</div>
				          		<div class="checkbox">
								    <label>
								    	<input name="is_active" type="hidden" value="off">
								      	<input name="is_active" class="is-active" type="checkbox" checked>
								      	Is active?
								    </label>
								</div>
							</div>
						</div>
					</div>
					<div class="modal-footer">
						<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
						<button type="submit" class="btn btn-primary">Add</button>
					</div>
					<?php echo Form::close(); ?>

				</div>
			</div>
		</div>
	</div>
	<div class="table-container">
		<table class="table webee-table" id="dataTable">
			<thead>
				<!-- <th></th> -->
				<th>Operator</th>
				<th>Chalet</th>
				<th>Address</th>
				<th>Notes</th>
				<th>Actions</th>
			</thead>
			<tbody>
				<?php $__currentLoopData = $operators; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $operator): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
				<tr class="<?php echo e($operator->is_active ? 'success' : 'danger'); ?>">
					<!-- <td><?php echo e($loop->iteration); ?></td> -->
					<td><?php echo e($operator->name); ?></td>
					<td>
						<?php $__currentLoopData = $operator->accommodations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $acc): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
						<?php if($acc->is_active == 1): ?>
							<p><?php echo e($acc->name); ?></p>
						<?php else: ?>
							<p class="strike"><?php echo e($acc->name); ?></p>
						<?php endif; ?>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
					</td>
					<td>
						<?php if($operator->web_address): ?>
						<p><i class="fa fa-globe"></i><a href="<?php echo e($operator->web_address); ?>" target="_blank"><?php echo e($operator->web_address); ?></a></p>
						<?php endif; ?>
						<?php if($operator->postal_address): ?>
						<p><i class="fa fa-map-marker"></i><?php echo e($operator->postal_address); ?></p>
						<?php endif; ?>
					</td>
					<td></td>
					<td>
						<?php if($operator->id != '1'): ?>
						<a href="<?php echo e(route('accommodation', $operator->id)); ?>" class="btn btn-primary btn-icon" title="View"><i class="fa fa-eye"></i></a>
						<a href="#" class="btn btn-success btn-icon" data-toggle="modal" data-target="#operator-modal-<?php echo e($operator->id); ?>" title="Edit"><i class="fa fa-pencil"></i></a>
						<div class="modal fade" id="operator-modal-<?php echo e($operator->id); ?>" tabindex="-1" role="dialog" aria-labelledby="editOperator">
							<div class="modal-dialog" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
										<h3 class="modal-title">Edit Chalet</h3>
									</div>
									<div class="modal-body">
										<div class="row">
											<div class="form-wrapper col-md-8 col-md-offset-2">
											<?php echo Form::open(array('route' => array('operator.update', $operator->id), 'method' => 'PUT', 'class' => 'edit-operator' )); ?>

												<div class="form-group">
									            	<?php echo e(Form::label('operator_name', 'Operator Name:')); ?>

									            	<?php echo e(Form::text('operator_name', $operator->name, array('class' => 'operator-name form-control', 'required' => ''))); ?>

								          		</div>
								          		<div class="form-group">
									            	<?php echo e(Form::label('web_address', 'Web Address:')); ?>

									            	<?php echo e(Form::text('web_address', $operator->web_address, array('class' => 'web-address form-control'))); ?>

								          		</div>
								          		<div class="form-group">
									            	<?php echo e(Form::label('postal_address', 'Postal Address:')); ?>

									            	<?php echo e(Form::text('postal_address', $operator->postal_address, array('class' => 'postal-address form-control'))); ?>

								          		</div>
								          		<div class="form-group">
									            	<?php echo e(Form::label('notes', 'Notes:')); ?>

									            	<?php echo e(Form::text('notes', $operator->notes, array('class' => 'notes form-control'))); ?>

								          		</div>
								          		<div class="checkbox">
												    <label>
												    	<input name="is_active" type="hidden" value="off">
												      	<input name="is_active" class="is-active" type="checkbox" <?php echo e($operator->is_active ? 'checked' : ''); ?>>
												      	Is active?
												    </label>
												</div>
											</div>
										</div>
									</div>
									<div class="modal-footer">
										<button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
										<button type="submit" class="btn btn-primary">Save</button>
									</div>
									<?php echo Form::close(); ?>

								</div>
							</div>
						</div>
						<a href="#" onclick="event.preventDefault(); confirmDelete(<?php echo e($operator->id); ?>);" class="btn btn-danger btn-icon" title="Delete"><i class="fa fa-trash"></i></a>
						<form id="delete-form-<?php echo e($operator->id); ?>" action="<?php echo e(route('operator.delete', $operator->id)); ?>" method="POST" style="display: none;">
	                        <?php echo e(csrf_field()); ?>

	                    </form>
						<?php endif; ?>
					</td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
			</tbody>
		</table>
	</div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script type="text/javascript" src="/js/jquery.dataTables.min.js"></script>
<script type="text/javascript">
	jQuery(document).ready(function() {
		jQuery('#dataTable').DataTable();
	});

	function confirmDelete(id) {
		var con = confirm('Are you sure you want to remove this entry?');

		if(con) {
			jQuery('#delete-form-' + id).submit();
		}
	}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>