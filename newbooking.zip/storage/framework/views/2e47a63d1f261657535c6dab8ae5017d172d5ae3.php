<div class="price-input-container">
	<div class="row">
		<div class="col-xs-2">
			<p>Day</p>
		</div>
		<div class="col-xs-5">
			<p>Without Boots</p>
		</div>
		<div class="col-xs-5">
			<p>With Boots</p>
		</div>
	</div>
	<?php $__currentLoopData = $package->prices; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $price): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
	<div class="row form-group">
		<div class="col-xs-2">
			<span class="day"><?php echo e($key); ?></span>
		</div>
		<div class="col-xs-5">
			<div class="input-group">
				<div class="input-group-addon">&euro;</div>
      			<input name="prices[<?php echo e($key); ?>][flat]" type="number" step="0.01" class="form-control" required value="<?php echo e($price->flat); ?>">
			</div>
		</div>
		<div class="col-xs-5">
			<div class="input-group">
				<div class="input-group-addon">&euro;</div>
      			<input name="prices[<?php echo e($key); ?>][boots]" type="number" step="0.01" class="form-control" required value="<?php echo e($price->boots); ?>">
			</div>
		</div>
	</div>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
</div>