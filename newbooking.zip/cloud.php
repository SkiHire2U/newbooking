gold is time
