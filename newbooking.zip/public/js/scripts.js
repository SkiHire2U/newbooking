jQuery(document).ready(function() {
	jQuery('[data-toggle="tooltip"]').tooltip();
});