<div class="title-bar">
    <div class="container">
        <div class="row">
            <h1>Booking</h1>
        </div>
    </div>
</div>